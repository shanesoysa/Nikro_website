<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>වහරක පන්සල | අප ගැන</title>
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/screen.css">
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />
<link rel="shortcut icon" href="images/favicon2.png">
</head>
<body>

<?php require_once('header.php'); ?>
 

<section class="slider">
	<img src="images/aboutUs.jpg" width="100%" alt=""/>
    <!-- flexslider ends here --> 
  </section>
  <!-- slider ends here -->
  <div class="container">
  <hr class="separator1">
  <p>Semper sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor. Semper sit amet bibendum ac, tincidunt sit Semper amet eros. In scelerisque vestibulum tempor. Semper sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor. sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor. Semper sit amet bibendum ac, tincidunt sit amet eros. In scelerisque semper vestibulum tempor.  Sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor.</p>
  
  <p>Semper sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor.Semper sit amet bibendum ac, tincidunt sit Semper amet eros. In scelerisque vestibulum tempor. Semper sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor. sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor. Semper sit amet bibendum ac, tincidunt sit amet eros. In scelerisque semper vestibulum tempor.  Sit amet bibendum ac, tincidunt sit amet eros. In scelerisque vestibulum tempor.</p>
 
</div>
<!-- container ends here --> 
  


<hr class="separator2">
<div class="socialsblock">
  <div class="container socialize">
    <h3 style="color:#000; font-family: 'apex-a.pura-010regular'; font-size:50px; margin-top:15px; text-shadow:1px 1px 0px #fff;">fy< fjolu</h3>
	<p style="color:#000; margin-top:30px;">
    	wm uyd iïud iïnqÿ mshdKka jykafia Ôjudkj jevisá wjêfha f,dal i;ajhd yg" ;uka jykafia úiska jgyd.;a Y%S ioaO¾uh foaYkd lsÍu Wfoid fukau" NslaIq NslaIqKska jykafia,df.a ksjkau wjfndaO lr.ekSu i|yd ieliqkdjQ mqckSh mqoìï w;súYd, m%udKhla f,dj mqrd wog;a me;sr mj;afkah' iïud iïnqÿ mshdKka jykafia úiska tod ch Y%S uyd fndaê uq,fha§ p;=rd¾h‌‌‍H i;H O¾uh wjfndaOh ;ska nqoaO;ajhg m;a jQ fial' lsisÿ .=rejrhl=f.a uÛ fmkaùulska f;drj ;uka jykafia úiskau jgyd.;a w;s W;=ï Y%S ioaO¾uh f,dal i;ajhd flfrys WmkakdjQ uy;a ohdkqlïmdj fya;= fldgf.k fï Nhxldr iifrka Tjqka uqojd ksjkauÛ mq¾Kh lr.ekSug ud¾.h i,iñka O¾uh wjfndaO lr.;a uyd ix>r;akh yeg kula ud¾.fhka m%:u O¾u m%pdrh wdrïN l< fial' ksjk wjfndaO lryels foaYkdjla" wm uyd nqÿ mshdKka jykafiaf.a fndaêi;aj wjêfha § Wkajykafiag l< fkdyels jQ nj iïnqoaO foaYkdfõu i|yka fõ' fnd÷kqjkaf.a is;a ;ska ksjk kue;s wudiqjh .s,sysf.dia f,!lsl iem iïm;a miqmiu Tjqka yud hkafka ksjka olskakg ;rï msx fï Njh ;u ;uka i;=j fkdue;s hehs fmdÿ u;hl msysgñKs' fuu fya;=j ksid u;= ixidr .uk ;= § ksjka oelSug ork W;aidyhla fndfyda fnd÷kqjkaf.ka fmkakqïflf¾' tfia kuq;a fuu mskaj;=ka w;ßka iir ÿlska ñ§ug fya;= jdikd we;s msßi i;H wjfndaOh ,nkf;lau fkdkj;ajd l,K ñ;=re weiqr fidhñka oyï wei újr lr .ekSug m%h;ak orhs' fnd÷kqjkayg l,K ñ;=re weiqrla ;ska oyï u. 
    </p>
  </div>
  <!-- container ends here --> 
  
  
  
  
<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script> 
<!-- Main js files --> 
<script src="js/screen.js" type="text/javascript"></script> 
<!-- Tabs --> 
<script src="js/tabs.js" type="text/javascript"></script> 
<!-- Include prettyPhoto --> 
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<!-- Include Superfish --> 
<script src="js/superfish.js" type="text/javascript"></script> 
<script src="js/hoverIntent.js" type="text/javascript"></script> 
<!-- Flexslider --> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<!-- Modernizr --> 
<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>


<?php require_once('footer.php'); ?>
</body>
</html>