<!-- Footer ==================================================
================================================== -->
<div class="footer">
  <div class="container">
    <div class="one_fourth">
      <h3>wm.ek úuiSï</h3>
      <p class="p2"><span class="orange"><strong>,smskh (</strong></span> <br>
        <span class="p4">j,a.ïm;" f.dak.,afoksh'</span></p>
      <p class="p2"><span class="orange"><strong>ÿrl:k (</strong></span> <br>
        <span class="p3">036 22 67 111</span><br>
      </p>
      <p class="p2"><span class="orange"><strong>B-fï,a (</strong></span> <br>
        <span style="font-family:Arial, Helvetica, sans-serif;">info@waharaka.com</span><br>
      </p>
    </div>
    <!-- four columns ends here -->
    <div class="one_fourth">
      <h3>úfYaI mqj;a</h3>
      <ul>
        <li><a href="#" title="">Development Blog</a></li>
        <li><a href="#" class="">New Freebies</a></li>
        <li><a href="#" class="">Themeforest Theme</a></li>
        <li><a href="#" class=""> Design News</a></li>
        <li><a href="#" class="">WordPress Theme</a></li>
      </ul>
    </div>
    <!-- four columns ends here -->
    <div class="one_fourth">
      <h3>miq.sh ,sms</h3>
      <ul>
        <li><a href="#" class=""> August 2012</a></li>
        <li><a href="#" class="">July 2012</a></li>
        <li><a href="#" class="">Juny 2012</a></li>
        <li><a href="#" class=""> May 2012</a></li>
        <li><a href="#" class="">April 2012</a></li>
      </ul>
    </div>
    <!-- four columns ends here -->
    <div class="one_fourth lastcolumn">
      <h3>wm.ek ì|la</h3>
      <p>iïu; fn!oaO úydria:dkhl ;sfnkakdjQ wx. iqúfYaIs wdldrhg ksulr we;s w;r ta ish,a, ;%súO r;akh flfrys wiSñ; Ñ;a; m%idohla kefÛk wdldrhg fukau" wiSñ; wdYS¾jdohla ,nd.; yels wdldrhg fuu  msx ìu ;=< ilid we;'</p>
      
    </div>
    <!-- four columns ends here --> 
  </div>
  <!-- container ends here --> 
</div>
<!-- footer ends here --> 
<!-- Copyright ==================================================
================================================== -->
<div id="copyright">
  <div class="container">
    <p class="copyright">ish¿u ysñlï weúßKs - 2017</p>
  </div>
  <!-- container ends here --> 
</div>
<!-- copyright ends here --> 