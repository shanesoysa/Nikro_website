<!-- Slider ==================================================
================================================== -->
<section class="slider">
  <div class="flexslider">
    <ul class="slides">
      <li> <img src="images/flexslider/1.jpg" width="100%" alt=""/></li>
      <li> <img src="images/flexslider/2.jpg" width="100%" alt="" /> </li>
      <li> <img src="images/flexslider/3.jpg" width="100%" alt="" /></li>
      <li> <img src="images/flexslider/4.jpg" width="100%" alt="" /></li>
    </ul>
  </div>
  <!-- flexslider ends here --> 
</section>
<!-- slider ends here --> 
<!-- info Box ==================================================
================================================== -->
<div class="infobox">
  <div class="container info">
    <header>
      <h1 style="font-family:'apex-a.pura-010regular';">wßis;=ï .s,dfkdamia:dk - ±lau</h1>
      <p class="infop" style="color:#000; text-align:center;">Tnf.a .f;a isf;a ksfrda.SNdjh W;=ï .=K mQ¾Kh msKsi fya;= fõjd'''æ</p>
    </header>
    <hr class="separator">
  </div>
  <!-- container ends here --> 
</div>
<!-- infobox ends here -->
<!-- Scripts ==================================================
================================================== --> 
<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script> 
<!-- Main js files --> 
<script src="js/screen.js" type="text/javascript"></script> 
<!-- Tabs --> 
<script src="js/tabs.js" type="text/javascript"></script> 
<!-- Include prettyPhoto --> 
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<!-- Include Superfish --> 
<script src="js/superfish.js" type="text/javascript"></script> 
<script src="js/hoverIntent.js" type="text/javascript"></script> 
<!-- Flexslider --> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<!-- Modernizr --> 
<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>