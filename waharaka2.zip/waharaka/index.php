<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>වහරක පන්සල | මුල් පිටුව</title>
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/screen.css">
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />
<link rel="shortcut icon" href="images/favicon2.png">
</head>
<body>

<?php require_once('header.php'); ?>
<?php require_once('slider.php'); ?>

<div class="sp_body2"><!-- sp_body --> 
<div class="container">
  <div class="ten columns alpha">
    
    <article class="post">
      <!--<h3>fu;a .,kd msx ìu</h3>-->
      <img class="shadow" src="images/blog/3.jpg" alt=""/>
      <div class="entry-date">
        <div class="number">03 DEC</div>
      </div>
      <p style="color:#000;">
      wm uyd iïud iïnqÿ mshdKka jykafia Ôjudkj jevisá wjêfha f,dal i;ajhd yg" ;uka jykafia úiska jgyd.;a Y%S ioaO¾uh foaYkd lsÍu Wfoid fukau" NslaIq NslaIqKska jykafia,df.a ksjkau wjfndaO lr.ekSu i|yd ieliqkdjQ mqckSh mqoìï w;súYd, m%udKhla f,dj mqrd wog;a me;sr mj;afkah'
iïud iïnqÿ mshdKka jykafia úiska tod ch Y%S uyd fndaê uq,fha§ p;=rd¾h‌‌‍H i;H O¾uh wjfndaOh ;ska nqoaO;ajhg m;a jQ fial' lsisÿ .=rejrhl=f.a uÛ fmkaùulska f;drj ;uka jykafia úiskau jgyd.;a w;s W;=ï Y%S ioaO¾uh f,dal i;ajhd flfrys WmkakdjQ uy;a ohdkqlïmdj fya;= fldgf.k fï Nhxldr iifrka Tjqka uqojd ksjkauÛ mq¾Kh lr.ekSug ud¾.h i,iñka O¾uh wjfndaO lr.;a uyd ix>r;akh yeg kula ud¾.fhka m%:u O¾u m%pdrh wdrïN l< fial'
ksjk wjfndaO lryels foaYkdjla" wm uyd nqÿ mshdKka jykafiaf.a fndaêi;aj wjêfha §  Wkajykafiag l< fkdyels jQ nj iïnqoaO foaYkdfõu i|yka fõ'
fnd÷kqjkaf.a is;a ;ska ksjk kue;s wudiqjh .s,sysf.dia f,!lsl iem iïm;a miqmiu Tjqka yud hkafka ksjka olskakg ;rï msx fï Njh  ;u ;uka i;=j fkdue;s hehs fmdÿ u;hl msysgñKs' fuu fya;=j ksid u;= ixidr .uk ;= § ksjka oelSug ork W;aidyhla fndfyda fnd÷kqjkaf.ka fmkakqïflf¾' tfia kuq;a fuu mskaj;=ka w;ßka iir ÿlska ñ§ug fya;= jdikd we;s msßi i;H wjfndaOh ,nkf;lau fkdkj;ajd l,K ñ;=re weiqr fidhñka oyï wei újr lr .ekSug m%h;ak orhs'
fnd÷kqjkayg l,K ñ;=re weiqrla ;ska oyï u. jeãug iqÿiqu mßirhla inr.uqj mdf;a" lE.,a, Èia;%slal udhsfï  msysá jyrl f.dak.,afoKsh kï .ïudkfha iqkaor fukau ksial,xl mßirhl msysgd we;s jyrl wßh Ñka;dY%u fn!oaO úydria:dkh  ;= ks¾udKhù ;sfí' i;r È.ska meñfKk mskaj;a odhl msßia j, odhl;ajfhkau b¢fjñka mj;sk fuu mqKH Nqñh ;=< § Tng‍" Y%jKh lsÍug ,efnk ioyï foaYkd ;=,ska ksjkau. weysÍ fkdue;snj ukdfldg m%;hlaIhjkq fkdjkqudkh'
      </p>
      <a href="singleblog.html">more <span>+</span></a> </article>
  </div>
  <!-- ten columns ends here -->
<?php require_once('right.php'); ?>
	</div>
<!-- container ends here --> 
</div><!-- sp_body --> 


<hr class="separator2">
<div class="socialsblock">
  <div class="container socialize">
    <h3 style="color:#000; font-family: 'apex-a.pura-010regular'; font-size:50px; margin-top:15px; text-shadow:1px 1px 0px #fff;">fy< fjolu</h3>
	<p style="color:#000; margin-top:30px;">
    	wm uyd iïud iïnqÿ mshdKka jykafia Ôjudkj jevisá wjêfha f,dal i;ajhd yg" ;uka jykafia úiska jgyd.;a Y%S ioaO¾uh foaYkd lsÍu Wfoid fukau" NslaIq NslaIqKska jykafia,df.a ksjkau wjfndaO lr.ekSu i|yd ieliqkdjQ mqckSh mqoìï w;súYd, m%udKhla f,dj mqrd wog;a me;sr mj;afkah' iïud iïnqÿ mshdKka jykafia úiska tod ch Y%S uyd fndaê uq,fha§ p;=rd¾h‌‌‍H i;H O¾uh wjfndaOh ;ska nqoaO;ajhg m;a jQ fial' lsisÿ .=rejrhl=f.a uÛ fmkaùulska f;drj ;uka jykafia úiskau jgyd.;a w;s W;=ï Y%S ioaO¾uh f,dal i;ajhd flfrys WmkakdjQ uy;a ohdkqlïmdj fya;= fldgf.k fï Nhxldr iifrka Tjqka uqojd ksjkauÛ mq¾Kh lr.ekSug ud¾.h i,iñka O¾uh wjfndaO lr.;a uyd ix>r;akh yeg kula ud¾.fhka m%:u O¾u m%pdrh wdrïN l< fial' ksjk wjfndaO lryels foaYkdjla" wm uyd nqÿ mshdKka jykafiaf.a fndaêi;aj wjêfha § Wkajykafiag l< fkdyels jQ nj iïnqoaO foaYkdfõu i|yka fõ' fnd÷kqjkaf.a is;a ;ska ksjk kue;s wudiqjh .s,sysf.dia f,!lsl iem iïm;a miqmiu Tjqka yud hkafka ksjka olskakg ;rï msx fï Njh ;u ;uka i;=j fkdue;s hehs fmdÿ u;hl msysgñKs' fuu fya;=j ksid u;= ixidr .uk ;= § ksjka oelSug ork W;aidyhla fndfyda fnd÷kqjkaf.ka fmkakqïflf¾' tfia kuq;a fuu mskaj;=ka w;ßka iir ÿlska ñ§ug fya;= jdikd we;s msßi i;H wjfndaOh ,nkf;lau fkdkj;ajd l,K ñ;=re weiqr fidhñka oyï wei újr lr .ekSug m%h;ak orhs' fnd÷kqjkayg l,K ñ;=re weiqrla ;ska oyï u. 
    </p>
  </div>
  <!-- container ends here --> 
</div>


<?php require_once('footer.php'); ?>
</body>
</html>