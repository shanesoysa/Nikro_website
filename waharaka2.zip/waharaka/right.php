<aside class="six columns omega shadow1">
    <section class="recentnews">
      <h4 class="sidebarheader">ùäfhda f.dkqj</h4>
      
      <ul class="tabs-content">
        <li class="active" id="trends">
          <p>
          		<a href=""><img src="images/video_gallery.jpg" width="100%" ></a>
          </p>
        </li>
        <li id="fashion">
          <p>Lorem ipsum dolor sit amet, proscriptum videt ulteriori. Filiam sunt amore nec est cum autem est se in. Cellam sanctissima coniunx in lucem exempli paupers coniunx rex cum autem quod ait regem Ardalio. Filiam sunt amore nec est cum autem est se in.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
        </li>
        <li id="shows">
          <p>Lorem ipsum dolor sit amet, proscriptum videt ulteriori. Filiam sunt amore nec est cum autem est se in. Cellam sanctissima coniunx in lucem exempli paupers coniunx rex cum autem quod ait regem Ardalio. Filiam sunt amore nec est cum autem est se in.Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam,feugiat vitae, ultricies eget, tempor sit amet, ante.</p>
        </li>
      </ul>
    </section>
    <!--end recent news-->
    <section class="latestphotos">
      <h4 class="sidebarheader">mska;+r f.dkqj</h4>
      <div class="one_half"> <img class="shadow" src="images/gal1.jpg" alt="work1" /> </div>
      <div class="one_half lastcolumn"> <img class="shadow" src="images/gal2.jpg" alt="work2" /> </div>
      <div class="one_half"> <img class="shadow" src="images/gal3.jpg" alt="work3" /> </div>
      <div class="one_half lastcolumn"> <img class="shadow" src="images/gal4.jpg" alt="work4" /> </div>
      <div class="one_half"> <img class="shadow" src="images/gal5.jpg" alt="work3" /> </div>
      <div class="one_half lastcolumn"> <img class="shadow" src="images/gal6.jpg" alt="work4" /> </div>
      
    </section>
    <!--end latestphotos-->
    
    
    <!--end categories--> 
  </aside>
  <!--end six columns--> 