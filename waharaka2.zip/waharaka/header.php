<div id="header2">
  <div class="container">
    <!-- Header | Logo, Menu
		================================================== -->
    <div class="logo"><a href="index.php"><img src="images/logo.png" width="250" alt="" style="border:none;" /></a></div>
    <div class="top_right">wßis;=ï iqjfi;<br/>
.s,dfkdamia:dk<br/>
	<span style="font-family: 'fmmalithix'; font-size:19px;">- .evnú,</span>
	</div>
    
    <div class="langBar">
  		<span><strong>English</strong></span> | 
        <span style="font-size:15px;"><strong>සිංහල</strong></span>
  	</div>
    
  </div>
  <!-- container ends here --> 
</div>
<!-- header ends here --> 


<div id="header">
  <div class="container"> 
    <!-- Header | Logo, Menu
		================================================== -->
    
    <div class="mainmenu">
      <div id="mainmenu">
        <ul class="sf-menu">
          <!--<li><a href="index.php" id="visited">uq,a msgqj</a></li>-->
          <li><a href="index.php" <?php if(basename($_SERVER['PHP_SELF'])=="index.php") { echo "class='aActive'";  }
		else{ echo "class=''"; } ?> >uq,a msgqj</a></li>
          <li><a href="aboutUs.php" <?php if(basename($_SERVER['PHP_SELF'])=="aboutUs.php") { echo "class='aActive'";  }
		else{ echo "class=''"; } ?> >wm l< foa</a></li>
          <li><a href="">wmf.a fiajdjka</a></li>
          <li><a href="">T!IO</a></li>
          <li><a href="">,sms</a></li>
          <li><a href="">O¾u foaYkd</a></li>
          <li><a href="">úuiSï</a></li>
        </ul>
      </div>
      <!-- mainmenu ends here --> 
      
      <!-- Responsive Menu -->
      <form id="responsive-menu" action="#" method="post">
        <select>
          <option value="">Navigation</option>
          <option value="index.php">Home</option>
          <option value="aboutUs.php">About Us</option>
          <option value="portfolio.html">Portfolio</option>
          <option value="portfolioproject.html">Portfolio Project</option>
          <option value="blog.html">Blog</option>
          <option value="singleblog.html">Single Post</option>
          <option value="features.html">Features</option>
          <option value="contact.html">Contact</option>
        </select>
      </form>
    </div>
    <!-- mainmenu ends here --> 
  </div>
  <!-- container ends here --> 
</div>
<!-- header ends here --> 